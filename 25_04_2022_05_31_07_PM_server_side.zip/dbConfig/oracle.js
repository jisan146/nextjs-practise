
  module.exports = {
    user: "coredb",
    password: "123",
    connectString: "localhost:1521/orcl"
  };

