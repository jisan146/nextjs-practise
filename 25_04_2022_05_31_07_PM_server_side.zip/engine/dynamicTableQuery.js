
var gv = require('./globalVariable');
var apiSecurity = require('./apiSecurity');
var gloDBconn = require('./gloDBconn');



module.exports = function (app) {




   


};