
var mysql = require('../dbConfig/mysql');
var oracle = require('../dbConfig/oracle');
var gv = require('./globalVariable');
const oracledb = require('oracledb');
var apiSecurity = require('./apiSecurity');
const fs = require('fs');
var uuid = require('uuid');
var gloDBconn = require('./gloDBconn');
var globalLog = require('./globalLog');


module.exports = function (app) {


};