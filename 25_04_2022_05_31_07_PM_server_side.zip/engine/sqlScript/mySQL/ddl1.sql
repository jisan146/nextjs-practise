

--
--
--

create table pos_product
(
 sl double NOT NULL AUTO_INCREMENT,
 barcode double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL AUTO_INCREMENT,
 barcode double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL AUTO_INCREMENT,
 barcode double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL AUTO_INCREMENT,
 barcode double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL AUTO_INCREMENT,
 barcode double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL AUTO_INCREMENT,
 barcode double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL AUTO_INCREMENT,
 barcode double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL AUTO_INCREMENT,
 barcode double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_test
(
 sl double NOT NULL AUTO_INCREMENT,
 col double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table undefined
(
 sl double NOT NULL AUTO_INCREMENT,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table undefined
(
 sl double NOT NULL AUTO_INCREMENT,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table undefined
(
 sl double NOT NULL AUTO_INCREMENT,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_test
(
 sl double NOT NULL AUTO_INCREMENT,
 a text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_test
(
 sl double NOT NULL AUTO_INCREMENT,
 a text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_test
(
 sl double NOT NULL AUTO_INCREMENT,
 a text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 1 double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 n double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 n double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 n double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 n double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 n double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 n double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 n double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 abc double, def double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a undefined, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_p
(
 sl double NOT NULL AUTO_INCREMENT,
 a text, b double, c double, d double, e double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_abc
(
 sl double NOT NULL AUTO_INCREMENT,
 a double, b text, c double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product_attribute
(
 sl double NOT NULL AUTO_INCREMENT,
 attribute text, attribute_type double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table application_options
(
 sl double NOT NULL AUTO_INCREMENT,
 option text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table application_options
(
 sl double NOT NULL AUTO_INCREMENT,
 application_options text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_supplier
(
 sl double NOT NULL ,
 supplier_code text, supplier_name text, phone1 text, phone2 text, phone3 text, license_info text, license_copy text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_supplier
(
 sl double NOT NULL ,
 supplier_code text, supplier_name text, phone1 text, phone2 text, phone3 text, license_info text, license_copy text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_supplier
(
 sl double NOT NULL ,
 supplier_code text, supplier_name text, phone1 text, phone2 text, phone3 text, license_info text, license_copy text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_supplier
(
 sl double NOT NULL ,
 supplier_code text, supplier_name text, phone1 text, phone2 text, phone3 text, license_info text, license_copy text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_supplier
(
 sl double NOT NULL ,
 supplier_code text, supplier_name text, phone1 text, phone2 text, phone3 text, license_info text, license_copy text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_supplier
(
 sl double NOT NULL ,
 supplier_code text, supplier_name text, phone1 text, phone2 text, phone3 text, license_info text, license_copy text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_supplier
(
 sl double NOT NULL ,
 supplier_code text, supplier_name text, phone1 text, phone2 text, phone3 text, license_info text, license_copy text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_supplier
(
 sl double NOT NULL ,
 supplier_code text, supplier_name text, phone1 text, phone2 text, phone3 text, license_info text, license_copy text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table abc
(
 sl double NOT NULL ,
 a double, b text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table def
(
 sl double NOT NULL ,
 a double, b text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table def
(
 sl double NOT NULL ,
 a double, b text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table deff
(
 sl double NOT NULL ,
 a double, b text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table defft
(
 sl double NOT NULL ,
 a double, b text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_category
(
 sl double NOT NULL ,
 category double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_subcategory
(
 sl double NOT NULL ,
 subcategory text, category double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_origin
(
 sl double NOT NULL ,
 origin text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table brand
(
 sl double NOT NULL ,
 brand text, origin double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_brand
(
 sl double NOT NULL ,
 brand text, origin double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_size
(
 sl double NOT NULL ,
 size text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_color
(
 sl double NOT NULL ,
 color text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table application_options_sub
(
 sl double NOT NULL ,
 application_options double, sub_options text, sub_options_value double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table designation
(
 sl double NOT NULL ,
 designation text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table department
(
 sl double NOT NULL ,
 department text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table employee
(
 sl double NOT NULL ,
 employee_id text, employee_name text, department double, designation double, phone text, email text, join_date date, nid double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_unit
(
 sl double NOT NULL ,
 unit text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL ,
 product_code text, barcode text, name text, cost double, sale_price double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product
(
 sl double NOT NULL ,
 name text, product_code text, barcode text, cost text, discount double, vat double, tax double, sale_price double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product_inventory
(
 sl double NOT NULL ,
 product_code double, cost double, qty double, purchase_date date,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product_purchase
(
 sl double NOT NULL ,
 product_code text, supplier double, qty double, cost double, purchase_date date,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product_purchase
(
 sl double NOT NULL ,
 product_code text, supplier double, qty double, cost double, purchase_date date,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table menu_access_group
(
 sl double NOT NULL ,
 group_name text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table menu_access_control
(
 sl double NOT NULL ,
 group_id double, page_id double, view_sl double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_customer
(
 sl double NOT NULL ,
 membership_id text, name text, phone1 text, phone2 text, address text, organization text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_principal_sector
(
 sl double NOT NULL ,
 sector text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_principal_sub_sector
(
 sl double NOT NULL ,
 sub_sector text, principal_sector double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_journal
(
 sl double NOT NULL ,
 explanation text, debit double, credit double, journal_sl double, journal_date date,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table application_sub_select
(
 sl double NOT NULL ,
 parent_select text, value text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_org_owners
(
 sl double NOT NULL ,
 name text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_org_owner
(
 sl double NOT NULL ,
 name text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_org_owner
(
 sl double NOT NULL ,
 name text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_org_owner
(
 sl double NOT NULL ,
 name text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_org_owner
(
 sl double NOT NULL ,
 name text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_org_owner
(
 sl double NOT NULL ,
 name text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_org_owner
(
 sl double NOT NULL ,
 name text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_head
(
 sl double NOT NULL ,
 head_name text, base double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_payment_method
(
 sl double NOT NULL ,
 method text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_multi_transection
(
 sl double NOT NULL ,
 dr double, cr double, sub_sector double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table org_default_options
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_customer_payment
(
 sl double NOT NULL ,
 invoice double, payment_method double, amount double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table client_details
(
 sl double NOT NULL ,
 name text, address_line_1 text, address_line_2 text, contact text, logo text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 a double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 name date, doj date,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test
(
 sl double NOT NULL ,
 name date, doj date,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_product_return
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_warranty_info
(
 sl double NOT NULL ,
 product_code double, product_sn text, details text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table accounts_party_category
(
 sl double NOT NULL ,
 category text, val double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table virtual_row
(
 sl double NOT NULL ,
 val text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table pos_global_rate
(
 sl double NOT NULL ,
 category double, unit double, rate double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table rubayet_test_student
(
 sl double NOT NULL ,
 name text, roll double, email text, father text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test123456
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test123456
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table test1234567
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table testjisan
(
 sl double NOT NULL ,

 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table testjisanabc
(
 sl double NOT NULL ,
 abc text,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table bwdb_geo_bag_chip
(
 sl double NOT NULL ,
 chip_id text, placed double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);

--
--
--

create table bwdb_project_plan
(
 sl double NOT NULL ,
 week double, plan double,
 org_id double NOT NULL, 
 branch double NOT NULL,
 dml_by double NOT NULL,
 dml_time timestamp NOT NULL, 
 PRIMARY KEY (sl)
);