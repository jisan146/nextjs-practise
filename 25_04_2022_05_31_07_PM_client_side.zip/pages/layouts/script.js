import React, { Component } from 'react';

class script extends Component {





    render() {

        return (


            <>
                <script src="/assets/bundles/lib.vendor.bundle.js"></script>
                <script src="/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
                <script src="/assets/plugins/dropify/js/dropify.min.js"></script>
                <script src="/assets/bundles/summernote.bundle.js"></script>
                <script src="/assets/js/core.js"></script>
                <script src="/assets/js/form/dropify.js"></script>
                <script src="/assets/js/page/summernote.js"></script>

                {/*<script src="/select2/js/select2.full.min.js"></script>*/}

            </>

        )
    }
}

export default script;
