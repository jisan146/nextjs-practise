import React, { Component } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import cookie from 'react-cookies'
import Table from '../layouts/Table';
import Grid from '../layouts/Grid';
import DetailsView from '../layouts/DetailsView';
import PageTitleAndTab from '../layouts/PageTitleAndTab';
import Head from 'next/head'
import readXlsxFile from 'read-excel-file'
import Script from 'next/script'
String.prototype.initCap = function () {
    return this
        .toLowerCase()
        .replace(/_/g, " ")
        .replace(/(?:^|\s)[a-z]/g, function (m) {
            return m.toUpperCase();
        });
};
class DataImport extends Component {

    host = ""
    pageTitle = 'Data Import'
    page_id = '/Form/DataImport'


    requiredField = []
    allFiled = []
    dataImportOption = ['Employee', 'Student'];
    componentDidMount() {

        var host = cookie.load('host');
        this.host = host.host

        this.allFiled[''] = []
        this.requiredField[''] = []

        this.requiredField['Student'] = ["name", "class", "section", "roll", "gender", "general_contact", "academic_year"]
        this.allFiled['Student'] = ["name", "class", "section", "roll", "gender", "general_contact", "academic_year", "student_phone", "guardian_name", "guardian_relationship", "guardian_phone", "admission_number", "admission_date", "dob", "student_email", "current_address", "religion", "caste", "blood_group", "father_name", "father_phone", "father_occupation", "mother_name", "mother_phone", "mother_occupation", 'photo']

        this.allFiled['Employee'] = []
        this.requiredField['Employee'] = []



        axios
            .post(this.host + '/req/v5/privilege', { page_id: this.page_id })
            .then(response => {


                var privileges = Object.keys(response.data);

                for (var p = 0; p < privileges.length; p++) {
                    this.setState({ [privileges[p]]: response.data[privileges[p]] }, () => { });
                }

            })
            .catch(error => {

            })



    }






    constructor() {
        super()
        this.state = {
            console: "",
            tblCol: [],
            tblRow: [],
            dataImportOptionVal: '',
            dataImportOptionSelect: '',
            mapTblCol: [],
            mapTblRow: [],
            excelColstate: [],
            excelData: [],
            mapData: []
        }
    }
    excelColMaptoDB = []

    excelDataMapToDBDefaultVal = (event) => {


        if (event.target.name == 'excelDataMapToDBDefaultVal') {
            this.setState({ excelDataMapToDBDefaultValInput: event.target.value }, () => { });
        } else {
            this.setState({ [event.target.name]: event.target.value }, () => { });
        }


        var excelData = [], mapData = [];
        mapData = this.state.mapData
        excelData = this.state.excelData
        if (this.state.find != '' && this.state.replace != '' && event.target.name == 'apt') {
            for (var r = 0; r < excelData.length; r++) {



                try { mapData[r][this.state.excelDataMapToDBDefaultVal] = excelData[r][event.target.value].replaceAll(this.state.find, this.state.replace) }
                catch { }


                this.setState({ excelDataMapToDBDefaultValInput: '' }, () => { });
            }
        }
        else {
            for (var r = 0; r < excelData.length; r++) {


                mapData[r][this.state.excelDataMapToDBDefaultVal] = event.target.value
            }
        }

        this.setState({ mapData: mapData })


    }
    excelDataMapToDB = (event) => {
        this.arrayIndex = 0



        if (event.target.value == '' && this.excelColMaptoDB.indexOf(event.target.name) >= 0) {
            this.excelColMaptoDB.splice(this.excelColMaptoDB.indexOf(event.target.name), 1)
        }
        else if (event.target.value == 'd') {
            this.setState({ excelDataMapToDBDefaultValInput: '' }, () => { });
            this.setState({ excelDataMapToDBDefaultVal: event.target.name })
            this.setState({ replace: '' })
            this.setState({ find: '' })
            if (event.target.value != '' && this.excelColMaptoDB.indexOf(event.target.name) < 0) {
                this.excelColMaptoDB.push(event.target.name)
            }
            var btnclose = document.getElementById('w-change-open');
            btnclose.click()

        }
        else if (event.target.value != '' && this.excelColMaptoDB.indexOf(event.target.name) < 0) {
            this.excelColMaptoDB.push(event.target.name)
        }


        var excelData = [], mapData = [];
        mapData = this.state.mapData
        excelData = this.state.excelData
        for (var r = 0; r < excelData.length; r++) {


            mapData[r][event.target.name] = excelData[r][event.target.value]
        }
        this.setState({ mapData: mapData })

    }
    dataImportFor = ''
    dataMap = (event) => {
        this.arrayIndex = 0
        var mapData = [];
        this.excelColMaptoDB = []
        this.setState({ mapTblRow: [] })

        if (event.target.name == 'dataImportFor') {
            this.dataImportFor = event.target.value;
            this.setState({ mapTblCol: [] })
            this.setState({ mapData: [] })
            this.setState({ dataImportOptionVal: '' })
            this.setState({ dataImportOptionSelect: '' })



        } else if (event.target.name == 'dataImportOption') {
            this.setState({ dataImportOptionSelect: event.target.value })
            if (event.target.value == 'a') {
                this.setState({ mapTblCol: this.allFiled[this.dataImportFor] })
                this.setState({ dataImportOptionVal: this.dataImportFor })

                var excelData = []
                excelData = this.state.excelData
                for (var r = 0; r < excelData.length; r++) {
                    mapData.push({})

                    for (var j = 0; j < this.allFiled[this.dataImportFor].length; j++) {
                        mapData[r][this.allFiled[this.dataImportFor][j]] = ''
                    }
                }
                this.setState({ mapData: mapData })



            } else if (event.target.value == 'r') {
                this.setState({ mapTblCol: this.requiredField[this.dataImportFor] })
                this.setState({ dataImportOptionVal: this.dataImportFor })

                var excelData = []
                excelData = this.state.excelData
                for (var r = 0; r < excelData.length; r++) {
                    mapData.push({})

                    for (var j = 0; j < this.requiredField[this.dataImportFor].length; j++) {
                        mapData[r][this.requiredField[this.dataImportFor][j]] = ''
                    }
                }
                this.setState({ mapData: mapData })

            }
            else if (event.target.value == '') {
                this.setState({ mapData: [] })
                this.setState({ mapTblCol: [] })
                this.setState({ dataImportOptionVal: '' })
            }


        }



    }


    arrayIndex = 0
    onchg = (event) => {
        this.arrayIndex = 0
        this.excelColMaptoDB = []
        readXlsxFile(event.target.files[0]).then((rows) => {
            this.arrayIndex = 0

            this.setState({ tblRow: rows })
            this.setState({ tblCol: rows[0] })

            var data = [], excelCol = [];
            /*   var data = [], data1 = [], excelCol = [];
               for (var r = 1; r < rows.length; r++) {
                   data.push({})
                   for (var j = 0; j < rows[0].length; j++) {
                       data[r - 1][rows[0][j]] = rows[r][j]
                   }
               }
   
               for (var r = 1; r < rows.length; r++) {
                   data1.push({})
                   for (var j = 0; j < rows[0].length; j++) {
                       data1[r - 1][j] = rows[r][j]
                   }
               }
   */
            for (var r = 1; r < rows.length; r++) {
                data.push({})
                for (var j = 0; j < rows[0].length; j++) {
                    data[r - 1][j] = rows[r][j]
                }
            }

            for (var j = 0; j < rows[0].length; j++) {
                excelCol.push({})
                excelCol[j]['r'] = j
                excelCol[j]['v'] = rows[0][j]

            }
            this.setState({ excelColstate: excelCol })
            this.setState({ excelData: data })


            // console.log(data)
            /* 
              excelData:[],
            mapData:[]
            console.log(data)
             console.log(data1)
             console.log(excelCol)*/

        })

    }





    submit = async e => {


        var i = 0, submit = 0;
        for (i; i < this.requiredField[this.state.dataImportOptionVal].length; i++) {
            var temp = this.requiredField[this.state.dataImportOptionVal][i]
         
            if (this.excelColMaptoDB.indexOf(temp) >= 0) {
                submit = 1;
            } else {
                submit = 0;
                break;
            }
        }

        if (submit == 1) {
            
           
            var finalData = []
            for (i = 0; i < this.state.mapData.length; i++) {
                finalData.push({})
                for (var k = 0; k < this.excelColMaptoDB.length; k++) {
                    finalData[i][this.excelColMaptoDB[k]] = this.state.mapData[i][this.excelColMaptoDB[k]]
                }
            }

            axios
            .post(this.host + '/req/v6/dataImport', {dataFor:this.state.dataImportOptionVal,data:finalData})
            .then(response => {
                toast.success("Information Submitted", {
                    theme: "colored",
                    autoClose: 1000
                })
            }).catch(error => {

                toast.error("Failed to Submit Information", {
                    theme: "colored",
                    autoClose: 1000
                })
               
            })

        } else {
            toast.warn("Required Field Can't Empty", {
                theme: "colored",
                autoClose: 1000
            })
        }



    }

    render() {



        return (
            <>
                <Head>
                    <title>{this.state.title}</title>
                </Head>
                <div>


                    <div className="section-body mt-4">
                        <div className="container-fluid">
                            <div className="tab-content">

                                <div className="" id="">
                                    <div className="row clearfix">
                                        <div className="col-lg-3 col-md-12 col-sm-12">
                                            <div className="card">
                                                <div className="card-header">
                                                    <h3 className="card-title">Add xlsx file</h3>
                                                    <div className="card-options ">
                                                        <a href="#" className="card-options-collapse" data-toggle="card-collapse"><i className="fe fe-chevron-up" /></a>
                                                        <a href="#" className="card-options-remove" data-toggle="card-remove"><i className="fe fe-x" /></a>
                                                    </div>
                                                </div>
                                                <div className="card-body">
                                                    <div className="row clearfix">
                                                        <div className="col-md-12 col-sm-12">
                                                            <div className="form-group mt-2 mb-3">

                                                                <input name='photo' id='photo' onChange={this.onchg} style={{ border: '1px solid red' }} type="file" className="dropify" />
                                                                <small id="fileHelp" className="form-text text-muted"></small>
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-9 col-md-12 col-sm-12">
                                            <div className="card">
                                                <div className="card-header">
                                                    <h3 className="card-title">xlsx file Information</h3>
                                                    <div className="card-options ">
                                                        <a href="#" className="card-options-collapse" data-toggle="card-collapse"><i className="fe fe-chevron-up" /></a>
                                                        <a href="#" className="card-options-remove" data-toggle="card-remove"><i className="fe fe-x" /></a>
                                                    </div>
                                                </div>
                                                <div className="card-body">
                                                    <div className="row clearfix">
                                                        <div className="table-responsive">
                                                            <table className="table table-hover table-vcenter text-nowrap table-striped mb-0">
                                                                <thead>
                                                                    <tr>


                                                                        {this.state.tblCol.map(tableColName => {
                                                                            return <th>{tableColName}</th>
                                                                        })}
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {this.state.tblRow.map(tblAllRow => {
                                                                        this.arrayIndex = this.arrayIndex + 1
                                                                        if (this.arrayIndex > 1)
                                                                            return <tr>
                                                                                {
                                                                                    tblAllRow.map(tblRow => {
                                                                                        return <td>{tblRow}</td>
                                                                                    })
                                                                                }
                                                                            </tr>
                                                                    })}

                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div className="row clearfix">
                                        <div className="col-lg-3 col-md-12 col-sm-12">
                                            <div className="card">
                                                <div className="card-header">
                                                    <h3 className="card-title">Import Option</h3>
                                                    <div className="card-options ">
                                                        <a href="#" className="card-options-collapse" data-toggle="card-collapse"><i className="fe fe-chevron-up" /></a>
                                                        <a href="#" className="card-options-remove" data-toggle="card-remove"><i className="fe fe-x" /></a>
                                                    </div>
                                                </div>
                                                <div className="card-body">
                                                    <div className="row clearfix">
                                                        <div class="col-md-12 col-sm-12">


                                                            <div class="form-group">
                                                                <label className="col-form-label">Import For<span className="text-danger">*</span></label>
                                                                <select onChange={this.dataMap} className="form-control" id="dataImportFor" name="dataImportFor" style={{ border: '1px solid #A9A9A9' }}>
                                                                    <option value={''}>-- Import For --</option>
                                                                    {this.dataImportOption.map(dataImportOption => {
                                                                        return <option>{dataImportOption}</option>
                                                                    })}
                                                                </select>

                                                            </div>


                                                            <div class="form-group">
                                                                <label className="col-form-label">Data Import Option<span className="text-danger">*</span></label>
                                                                <select value={this.state.dataImportOptionSelect} onChange={this.dataMap} className="form-control" id="dataImportOption" name="dataImportOption" style={{ border: '1px solid #A9A9A9' }}>
                                                                    <option value={''}>-- Data Import Option --</option>
                                                                    <option value={'r'}>Required Field Only</option>
                                                                    <option value={'a'}>All Field</option>

                                                                </select>
                                                            </div>



                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-lg-9 col-md-12 col-sm-12">
                                            <div className="card">
                                                <div className="card-header">
                                                    <h3 className="card-title">Mapped Information</h3>
                                                    <div className="card-options ">
                                                        <a href="#" className="card-options-collapse" data-toggle="card-collapse"><i className="fe fe-chevron-up" /></a>
                                                        <a href="#" className="card-options-remove" data-toggle="card-remove"><i className="fe fe-x" /></a>
                                                    </div>
                                                </div>
                                                <div className="card-body">

                                                    <div className="row clearfix">
                                                        <div className="table-responsive">
                                                            <table className="table table-hover table-vcenter text-nowrap table-striped mb-0">
                                                                <thead>
                                                                    <tr>


                                                                        {this.state.mapTblCol.map(tableColName => {

                                                                            if (this.requiredField[this.state.dataImportOptionVal].indexOf(tableColName) >= 0) {
                                                                                return <th><div class="form-group">
                                                                                    <label className="col-form-label">{tableColName.initCap()}<span className="text-danger">*</span></label>
                                                                                    <select onChange={this.excelDataMapToDB} className="form-control" id={tableColName} name={tableColName} style={{ border: '1px solid #A9A9A9' }}>
                                                                                        <option value={''}>-- {tableColName.initCap()} --</option>
                                                                                        <option value={'d'}>[Input Data]</option>
                                                                                        {this.state.excelColstate.map(excelColstate => {
                                                                                            return <option value={excelColstate.r}>{excelColstate.v}</option>
                                                                                        })}
                                                                                    </select>
                                                                                </div></th>
                                                                            } else {
                                                                                // return <th>{tableColName}</th>
                                                                                return <th><div class="form-group">
                                                                                    <label className="col-form-label">{tableColName.initCap()}<span className="text-danger"></span></label>
                                                                                    <select onChange={this.excelDataMapToDB} className="form-control" id={tableColName} name={tableColName} style={{ border: '1px solid #A9A9A9' }}>
                                                                                        <option value={''}>-- {tableColName.initCap()} --</option>
                                                                                        <option value={'d'}>[Input Data]</option>
                                                                                        {this.state.excelColstate.map(excelColstate => {
                                                                                            return <option value={excelColstate.r}>{excelColstate.v}</option>
                                                                                        })}
                                                                                    </select>
                                                                                </div></th>
                                                                            }

                                                                        })}
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                    {this.state.mapData.map((tableAllRow) => (


                                                                        <tr>
                                                                            {this.state.mapTblCol.map(tableColName => {
                                                                                return <td><div className="font-15">{tableAllRow[tableColName]}</div></td>
                                                                            })}




                                                                        </tr>
                                                                    ))}


                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="card-footer">
                                                    <div class="row">
                                                        <div class="col-sm-12">


                                                            <button onClick={this.submit} class="btn btn-success float-right" >Upload Data</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </div>





                            </div>
                        </div>
                    </div>
                </div>
                <Script
                    strategy="afterInteractive"
                    dangerouslySetInnerHTML={{
                        __html: `
              $(function () {
                //Initialize Select2 Elements
                $('.dropify').dropify();

              })
  `,
                    }}
                />

                <Script
                    strategy="afterInteractive"
                    dangerouslySetInnerHTML={{
                        __html: `
          function   clearFileInput()
                    {
                        var drEvent = $('#photo').dropify();
drEvent = drEvent.data('dropify');
drEvent.resetPreview();
drEvent.clearElement();
                    }
  `,
                    }}
                />

                {/* Delete  */}
                <div class={"modal fade bd-example-modal-default_del"} tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-default">
                        <div class="modal-content">
                            <div class="card card-danger">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fa fa-refresh" aria-hidden="true"></i>&nbsp;Set Value For All Row</h3>
                                </div>
                                <div class="card-body">
                                    {/** Form Input Element Generator Start */}

                                    <div className="row clearfix">
                                        <div className="col-md-6 col-sm-12">
                                            <div className="form-group">
                                                <label className="col-form-label">Find Value<span className="text-danger"></span></label>
                                                <input value={this.state.find} onChange={this.excelDataMapToDBDefaultVal} className="form-control" id={'find'} name={'find'} style={{ border: '1px solid #A9A9A9' }} />
                                            </div>

                                        </div>
                                        <div className="col-md-6 col-sm-12">
                                            <div className="form-group">
                                                <label className="col-form-label">Replace Value<span className="text-danger"></span></label>
                                                <input value={this.state.replace} onChange={this.excelDataMapToDBDefaultVal} className="form-control" id={'replace'} name={'replace'} style={{ border: '1px solid #A9A9A9' }} />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row clearfix">
                                        <div className="col-md-12 col-sm-12">
                                            <div className="form-group">
                                                <label className="col-form-label">Apply To<span className="text-danger"></span></label>
                                                <select id={'apt'} name={'apt'} onChange={this.excelDataMapToDBDefaultVal} className="form-control" style={{ border: '1px solid #A9A9A9' }}>
                                                    <option value={''}>-- Apply To --</option>

                                                    {this.state.excelColstate.map(excelColstate => {
                                                        return <option value={excelColstate.r}>{excelColstate.v}</option>
                                                    })}
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row clearfix">
                                        <div className="col-md-12 col-sm-12">
                                            <div className="form-group">
                                                <label className="col-form-label">Default Value<span className="text-danger"></span></label>
                                                <input value={this.state.excelDataMapToDBDefaultValInput} onChange={this.excelDataMapToDBDefaultVal} className="form-control" id={'excelDataMapToDBDefaultVal'} name={'excelDataMapToDBDefaultVal'} style={{ border: '1px solid #A9A9A9' }} />
                                            </div>
                                        </div>
                                    </div>
                                    {/** Form Input Element Generator End*/}
                                </div>

                                <div class="card-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <button
                                                data-dismiss="modal" type="button"

                                                class="btn btn-success">
                                                Update Data
                                            </button>

                                            <button id="w-change-close" type="button" class="btn btn-secondary float-right" data-dismiss="modal">Cancel</button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/*  Modal */}
                <button id="w-change-open" name="w-change-open" type="button" data-type="confirm" data-toggle="modal" data-target={".bd-example-modal-default_del"}></button>
            </>
        )
    }
}
export default DataImport;
